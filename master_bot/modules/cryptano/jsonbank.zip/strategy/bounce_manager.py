"""
bounce_manager.py
==================
BOUNCE-специфичная часть менеджера, вынесенная в отдельный класс.

Шаг 1 переезда: код перенесён 1-в-1 из watcher_manager.py, ни одна строка
логики не изменена — только физическое место, где она живёт. WatcherManager
по-прежнему предоставляет наружу те же самые методы (evaluate_bounce,
evaluate_bounce_side, has_active_bounce_watchers) как тонкие обёртки —
test_simulator.py ничего не должен заметить.
"""

import os
import json
import pandas as pd

from .bounce_watcher import BounceWatcher

# Два независимых "режима" SHORT, работающих ОДНОВРЕМЕННО на одну и ту же
# resistance-зону: CLIMAX (SHORT_CLIMAX_MODE=True, 3 закрытия подряд перед
# входом) и MIRROR (зеркально LONG, вход от первого касания). Каждый вотчер
# получает свою СОБСТВЕННУЮ копию CONFIG (см. BounceWatcher.__init__) —
# поэтому оба семейства не мешают друг другу, даже запущенные в одном
# процессе. LONG эту раздвоенность не затрагивает вообще (mode=None).
SHORT_MODES = ('CLIMAX', 'MIRROR')


class BounceManager:
    CONFIG = {
        # Если середины двух уровней (одной стороны, LONG/LONG или SHORT/SHORT)
        # отличаются меньше чем на этот % — считаем их одним и тем же уровнем
        # (дрожание пересчёта базы раз в 12ч), не заводим второй вотчер.
        'LEVEL_DEDUP_TOLERANCE_PCT': 4.0,
        # "Кладбище": на сколько % цена должна уйти от мёртвой (DEAD/TRIGGERED)
        # зоны, чтобы система перестала считать новый уровень на этом месте клоном.
        'GRAVEYARD_ESCAPE_PCT': 5.0,
    }

    def __init__(self, parent, log_dir_override=None):
        """parent — это WatcherManager. Общая инфраструктура (_watchers,
        burned_levels, _level_id, _deny) пока остаётся там, чтобы её
        продолжали видеть и остальные стратегии — здесь только читаем её
        через parent, не дублируем.

        log_dir_override — своя папка логов для ВСЕХ вотчеров, созданных
        через этот менеджер (см. BounceWatcher.log_dir_override). None у
        боевого bounce_mgr (пишет в стандартный bounce_logs/), задаётся
        только симулятором (modules/cryptano/simulator/) — свой изолированный
        BounceManager(BounceParent(), log_dir_override=...) на каждый прогон."""
        self.parent = parent
        self.log_dir_override = log_dir_override
        # Счётчик реальных пробоев — источник для "конверсии" (пробитые уровни -> сделки).
        # Считается по событию SWEEP_BOTTOM, не по старому tracked_support (его для
        # BOUNCE больше нет — см. шаг 3 изоляции).
        self.pierced_count = 0
        # "Кладбище" мёртвых зон: [{'trade_type','min','max','escaped'}, ...].
        # Живёт, пока цена не уйдёт от зоны дальше GRAVEYARD_ESCAPE_PCT — до этого
        # момента новый уровень, пересчитанный на этом же месте (дрожание базы),
        # считается клоном, а не честным новым сетапом. См. _find_graveyard_match.
        self.graveyard = []
        self._graveyard_recorded = set()  # level_id, уже занесённые в кладбище
        # Время (unix-секунды) последней СВЕЧИ, которую BOUNCE реально обработал,
        # отдельно по каждой монете. Персистится (см. to_state_dict/load_state) —
        # нужно watcher_plan.py::check_bounce(), чтобы после рестарта бота
        # "догнать" (реплеить) все свечи, пропущенные за время простоя, а не
        # видеть только текущую и терять/сдвигать события во времени.
        self.last_processed_time = {}

    @property
    def _watchers(self):
        return self.parent._watchers

    @property
    def burned_levels(self):
        return self.parent.burned_levels

    def _level_id(self, level, trade_type):
        return self.parent._level_id(level, trade_type)

    def _deny(self, reason):
        return self.parent._deny(reason)

    def has_active_bounce_watchers(self, trade_type=None):
        """True, если есть хотя бы один живой (не DEAD/TRIGGERED) BOUNCE-вотчер.
        Нужно тестеру, чтобы не пропускать свечу, пока по уровню ещё идёт сканирование,
        даже если CURRENT_SUPPORTS/RESISTANCES на этот момент пусты."""
        for w in self._watchers.values():
            if trade_type is not None and getattr(w, 'trade_type', None) != trade_type:
                continue
            if getattr(w, 'state', None) not in ("DEAD", "TRIGGERED"):
                return True
        return False

    def _update_graveyard(self, c_close, coin="UNKNOWN"):
        """Вызывается раз в свечу. Отпускает мёртвую зону, как только цена
        реально ушла от неё дальше GRAVEYARD_ESCAPE_PCT — с этого момента
        уровень на этом месте больше не считается автоматически клоном.
        Фильтр по coin обязателен — без него c_close монеты A сравнивался
        бы с мёртвыми зонами вообще всех монет (кладбище общее на весь бот),
        давая случайные ложные escaped на чужих ценах."""
        tolerance = self.CONFIG['GRAVEYARD_ESCAPE_PCT'] / 100.0
        for entry in self.graveyard:
            if entry.get('coin') != coin:
                continue
            if entry['escaped']:
                continue
            escape_low = entry['min'] * (1 - tolerance)
            escape_high = entry['max'] * (1 + tolerance)
            if c_close < escape_low or c_close > escape_high:
                entry['escaped'] = True

    def _record_death(self, watcher, trade_type, level_id):
        """Заносит вотчер в кладбище один раз, в момент его смерти (DEAD/TRIGGERED)."""
        if level_id in self._graveyard_recorded:
            return
        self._graveyard_recorded.add(level_id)
        self.graveyard.append({
            'coin': getattr(watcher, 'coin', None),
            'trade_type': trade_type,
            'mode': getattr(watcher, 'mode', None),  # CLIMAX/MIRROR/None — не путать семьи между собой
            'min': watcher.min,
            'max': watcher.max,
            'escaped': False,
        })

    def _find_graveyard_match(self, level, trade_type, mode=None, coin="UNKNOWN"):
        """'clone'  — совпал с ещё не отпущенной мёртвой зоной, блокировать.
        'reborn' — совпал с уже отпущенной (цена сбегала и вернулась), разрешить.
        None     — совпадений в кладбище нет.
        Фильтр по coin обязателен — без него новый уровень монеты A мог
        ложно блокироваться как "клон" мёртвой зоны совсем другой монеты B,
        если их цены случайно оказались в одном диапазоне (частое дело для
        мелких альткоинов)."""
        tolerance = self.CONFIG['LEVEL_DEDUP_TOLERANCE_PCT'] / 100.0
        lvl_mid = (level['min'] + level['max']) / 2
        matched_escaped = False
        for entry in self.graveyard:
            if entry.get('coin') != coin:
                continue
            if entry['trade_type'] != trade_type or entry.get('mode') != mode:
                continue
            entry_mid = (entry['min'] + entry['max']) / 2
            if entry_mid > 0 and abs(lvl_mid - entry_mid) / entry_mid <= tolerance:
                if entry['escaped']:
                    matched_escaped = True
                else:
                    return 'clone'
        return 'reborn' if matched_escaped else None

    def evaluate_bounce_side(self, trade_type, touched_levels, evaluator, mode=None, coin="UNKNOWN"):
        """
        Перебирает ВСЕ уровни BOUNCE этой стороны (LONG/SHORT) И ЭТОГО mode
        (CLIMAX/MIRROR/None) ЭТОЙ КОНКРЕТНОЙ МОНЕТЫ, которые нужно проверить
        на этой свече:
          1. уже активные вотчеры (защита от того, что 12-часовое обновление
             CURRENT_SUPPORTS/RESISTANCES выкинет уровень, пока по нему ещё
             идёт сканирование)
          2. плюс новые уровни, которых свеча только что коснулась (touched_levels) —
             НО только если это правда новый уровень, а не дрожание уже
             отслеживаемого (см. LEVEL_DEDUP_TOLERANCE_PCT). Если новый кандидат
             похож на уже живой вотчер ЭТОГО ЖЕ mode — координаты живого вотчера
             остаются замороженными, второй вотчер не заводим. Вотчеры ДРУГОГО
             mode на той же зоне это не видят и не блокируют — climax и mirror
             живут полностью независимо, каждый в своём собственном пространстве
             дублей (см. mode в level_id и в фильтре active_mids ниже).

        КРИТИЧНО (найденный баг): self._watchers — ОДИН общий реестр на ВЕСЬ
        бот, не один на монету, как было в testswing/симуляторе. Без фильтра
        по coin здесь watcher.update() монеты A вызывался бы с ценой свечи
        монеты B на каждом скане монеты B — event_log монеты A заполнялся
        чужими ценами (RUNAWAY/SWEEP_BOTTOM с ценами десятков других монет
        в одном вотчере). coin обязателен для корректной работы в бою.

        evaluator(level_id, level) -> decision dict — вызывающий код сам считает
        контекст (тренд, ATR и т.д.) и зовёт self.evaluate_bounce(...); менеджер
        этого не делает, у него нет доступа к индикаторам симулятора.

        Возвращает список (level_id, level, decision) для ВСЕХ проверенных
        уровней — вызывающий код сам решает, что делать с решениями (войти,
        нарисовать событие на графике).
        """
        levels_to_eval = {}
        active_mids = []  # середины уже живых вотчеров этой стороны+mode — для сверки на дубли
        for level_id, w in list(self._watchers.items()):
            if getattr(w, 'coin', None) != coin:
                continue
            if w.trade_type == trade_type and getattr(w, 'mode', None) == mode and w.state not in ("DEAD", "TRIGGERED"):
                levels_to_eval[level_id] = {'min': w.min, 'max': w.max,
                                             'score': getattr(w, 'level_score', 0),
                                             'type': getattr(w, 'level_type', 'UNKNOWN')}
                active_mids.append((w.min + w.max) / 2)

        tolerance = self.CONFIG['LEVEL_DEDUP_TOLERANCE_PCT'] / 100.0

        for lvl in touched_levels:
            level_id = self._level_id(lvl, trade_type)
            if mode:
                level_id = f"{level_id}__{mode}"
            if level_id in levels_to_eval:
                continue

            lvl_mid = (lvl['min'] + lvl['max']) / 2
            is_duplicate = any(
                mid > 0 and abs(lvl_mid - mid) / mid <= tolerance
                for mid in active_mids
            )
            if is_duplicate:
                # Это дрожание уже отслеживаемого уровня — не заводим второй вотчер,
                # координаты живого остаются замороженными как есть.
                continue

            grave_status = self._find_graveyard_match(lvl, trade_type, mode=mode, coin=coin)
            if grave_status == 'clone':
                # Дрожание пересчёта на месте мёртвой зоны, цена никуда не уходила —
                # не даём вотчеру родиться заново с нуля.
                continue
            if grave_status == 'reborn':
                # Цена реально уходила и вернулась — честный новый сетап на старом
                # месте. Помечаем, чтобы вотчер и лог это знали (тег OD).
                lvl = dict(lvl)
                lvl['_reborn'] = True

            levels_to_eval[level_id] = lvl

        results = []
        for level_id, lvl in levels_to_eval.items():
            decision = evaluator(level_id, lvl)
            results.append((level_id, lvl, decision))
        return results

    def on_levels_refreshed(self, current_supports, current_resistances):
        """Вызывается тестером раз в 12 часов, когда обновилась база уровней
        (CURRENT_SUPPORTS/CURRENT_RESISTANCES). Строит набор ID уровней, которые
        сейчас актуальны, и просит менеджер убрать вотчеры для тех, кого в этом
        наборе больше нет (кроме защищённых состоянием — см. clear_dead_watchers).
        Для SHORT добавляем ОБА варианта id (__CLIMAX и __MIRROR) — иначе оба
        семейства вотчеров выглядели бы для этой проверки как 'уже неактуальные'
        и удалялись бы, хотя зона по факту всё ещё в CURRENT_RESISTANCES."""
        current_level_ids = set()
        for s in current_supports:
            current_level_ids.add(self._level_id(s, 'LONG'))
        for r in current_resistances:
            base_id = self._level_id(r, 'SHORT')
            for m in SHORT_MODES:
                current_level_ids.add(f"{base_id}__{m}")
        self.parent.clear_dead_watchers(current_level_ids)

    def _get_active_climax_id(self):
        """Фокус держится на уровне с максимальной стадией.
        Новый уровень заберет фокус, только когда дойдет до стадии SEARCHING."""
        STAGE_RANK = {'WAIT_MAX': 1, 'WAIT_BUFFER': 2, 'SEARCHING': 3}
        candidates = [
            (lid, w) for lid, w in self._watchers.items()
            if getattr(w, 'trade_type', None) == 'SHORT'
            and getattr(w, 'climax_stage', None) in STAGE_RANK
            and getattr(w, 'state', None) not in ("DEAD", "TRIGGERED")
        ]
        if not candidates:
            return None
        # Сначала сравниваем стадию, при равной стадии выигрывает самый верхний (max)
        return max(candidates, key=lambda item: (STAGE_RANK[item[1].climax_stage], item[1].max))[0]

    def get_active_climax_short(self):
        active_id = self._get_active_climax_id()
        if active_id is None:
            return None, None, None, None
            
        best = self._watchers.get(active_id)
        if best is None:
            return None, None, None, None
            
        return best.min, best.max, None, None


    def _get_focus_level_id(self, trade_type, mode=None, coin="UNKNOWN"):
        """Единый центр принятия решений по фокусу — отдельно для каждой
        комбинации trade_type+mode, И ОБЯЗАТЕЛЬНО в пределах одной монеты
        (см. предупреждение в evaluate_bounce_side выше — тот же класс
        бага: без фильтра по coin вотчер монеты A мог получить фокус или
        отказ в фокусе из-за вотчера совершенно другой монеты B). CLIMAX
        и MIRROR на одной и той же resistance-зоне никогда не конкурируют
        друг с другом за фокус — это два независимых потока сигналов."""
        # Новая логика для шортов в режиме Climax
        if trade_type == 'SHORT' and mode == 'CLIMAX':
            STAGE_RANK = {'WAIT_MAX': 1, 'WAIT_BUFFER': 2, 'SEARCHING': 3}
            candidates = [
                (lid, w) for lid, w in self._watchers.items()
                if getattr(w, 'coin', None) == coin
                and getattr(w, 'trade_type', None) == 'SHORT'
                and getattr(w, 'mode', None) == 'CLIMAX'
                and getattr(w, 'climax_stage', None) in STAGE_RANK
                and getattr(w, 'state', None) not in ("DEAD", "TRIGGERED")
            ]
            if not candidates:
                return None
            return max(candidates, key=lambda item: (STAGE_RANK[item[1].climax_stage], item[1].max))[0]

        # Старая логика — для LONG (mode=None) и для SHORT MIRROR (mode='MIRROR')
        candidates = [
            (lid, w) for lid, w in self._watchers.items()
            if getattr(w, 'coin', None) == coin
            and getattr(w, 'trade_type', None) == trade_type
            and getattr(w, 'mode', None) == mode
            and getattr(w, 'state', None) == "SCANNING"
            and getattr(w, 'pierced_bottom', False)
            and getattr(w, 'last_pierce_time', None) is not None
        ]
        if not candidates:
            return None
        if trade_type == 'LONG':
            return max(candidates, key=lambda item: (item[1].last_pierce_time, -item[1].min))[0]
        else:
            return max(candidates, key=lambda item: (item[1].last_pierce_time, item[1].max))[0]

    def get_zone_drawing(self, c_close, allow_long=True, allow_short=True):
        sup_min = sup_max = res_min = res_max = None

        if allow_long:
            focus_id = self._get_focus_level_id('LONG')
            if focus_id is not None:
                w = self._watchers.get(focus_id)
                if w is not None:
                    sup_min, sup_max = w.min, w.max
            else:
                active_longs = [w for w in self._watchers.values()
                                 if getattr(w, 'trade_type', None) == 'LONG'
                                 and getattr(w, 'state', None) not in ("DEAD", "TRIGGERED")]
                if active_longs:
                    near = min(active_longs, key=lambda w: abs(((w.min + w.max) / 2) - c_close))
                    sup_min, sup_max = near.min, near.max

        if allow_short:
            # Рисуем фокус CLIMAX, если он есть, иначе фокус MIRROR — чисто
            # для линии на графике (сигналы в лог идут от обеих семей
            # независимо от того, что тут нарисовано).
            focus_id = self._get_focus_level_id('SHORT', mode='CLIMAX') or self._get_focus_level_id('SHORT', mode='MIRROR')
            if focus_id is not None:
                w = self._watchers.get(focus_id)
                if w is not None:
                    res_min, res_max = w.min, w.max
            else:
                active_shorts = [w for w in self._watchers.values()
                                  if getattr(w, 'trade_type', None) == 'SHORT'
                                  and getattr(w, 'state', None) not in ("DEAD", "TRIGGERED")]
                if active_shorts:
                    near = min(active_shorts, key=lambda w: abs(((w.min + w.max) / 2) - c_close))
                    res_min, res_max = near.min, near.max

        return sup_min, sup_max, res_min, res_max

    def get_zone_drawing_multi(self, c_close, allow_long=True, allow_short=True):
        """То же самое, что get_zone_drawing, но НЕ схлопывает два независимых
        SHORT-режима (CLIMAX/MIRROR) в одну пару линий — отдаёт обе зоны сразу,
        каждую под своим ключом. Старый get_zone_drawing НЕ трогаем (может быть
        завязан код, которого мы не видим — и в бэктесте, и в веб-графике живого
        бота) — это ДОПОЛНИТЕЛЬНЫЙ метод, переходить на него нужно осознанно там,
        где действительно хотят видеть обе зоны одновременно.

        Возвращает dict:
            {
                'long':          (sup_min, sup_max) | (None, None),
                'short_climax':  (res_min, res_max) | (None, None),
                'short_mirror':  (res_min, res_max) | (None, None),
            }
        Если для какого-то ключа сейчас вообще нет ни одного активного вотчера
        (ни в фокусе, ни просто рядом с ценой) — оба значения None, рисовать
        для этого ключа нечего.
        """
        result = {
            'long': (None, None),
            'short_climax': (None, None),
            'short_mirror': (None, None),
        }

        if allow_long:
            focus_id = self._get_focus_level_id('LONG')
            if focus_id is not None:
                w = self._watchers.get(focus_id)
                if w is not None:
                    result['long'] = (w.min, w.max)
            else:
                active_longs = [w for w in self._watchers.values()
                                 if getattr(w, 'trade_type', None) == 'LONG'
                                 and getattr(w, 'state', None) not in ("DEAD", "TRIGGERED")]
                if active_longs:
                    near = min(active_longs, key=lambda w: abs(((w.min + w.max) / 2) - c_close))
                    result['long'] = (near.min, near.max)

        if allow_short:
            for mode, key in (('CLIMAX', 'short_climax'), ('MIRROR', 'short_mirror')):
                focus_id = self._get_focus_level_id('SHORT', mode=mode)
                if focus_id is not None:
                    w = self._watchers.get(focus_id)
                    if w is not None:
                        result[key] = (w.min, w.max)
                else:
                    active = [w for w in self._watchers.values()
                              if getattr(w, 'trade_type', None) == 'SHORT'
                              and getattr(w, 'mode', None) == mode
                              and getattr(w, 'state', None) not in ("DEAD", "TRIGGERED")]
                    if active:
                        near = min(active, key=lambda w: abs(((w.min + w.max) / 2) - c_close))
                        result[key] = (near.min, near.max)

        return result

    def process_candle(self, c_low, c_high, c_close, current_supports, current_resistances,
                        df_slice, allow_long=True, allow_short=True, c_atr=0.0, coin="UNKNOWN"):
        self._update_graveyard(c_close, coin=coin)

        orders = []
        draw_events = []

        def _collect_event(level_id, trade_type):
            w = self._watchers.get(level_id)
            if w is None:
                return
            et = getattr(w, 'last_event_type', None)
            if et == "SWEEP_BOTTOM":
                self.pierced_count += 1
                draw_events.append(('bounce_sweep', c_low if trade_type == 'LONG' else c_high))
            elif et == "SCAN":
                draw_events.append(('bounce_scan', c_close))
            elif et in ("GOOD_GREEN", "GOOD_RED"):
                draw_events.append(('bounce_good', c_close))
            elif et == "RUNAWAY":
                draw_events.append(('bounce_release', c_close))
            elif et in ("CLIMAX_NEAR_BREACH", "CLIMAX_FAR_BREACH"):
                draw_events.append(('climax_breach', c_high))

        if allow_long:
            focus_long_id = self._get_focus_level_id('LONG', coin=coin)
            touched_long = [s for s in current_supports if c_low <= s['max']]
            for level_id, lvl, decision in self.evaluate_bounce_side(
                    'LONG', touched_long,
                    lambda lid, l: self.evaluate_bounce(
                        l, df_slice, 'LONG', current_resistances,
                        is_focus=(focus_long_id is None or lid == focus_long_id), c_atr=c_atr,
                        coin=coin),
                    coin=coin):
                _collect_event(level_id, 'LONG')
                if decision.get('allow'):
                    actual_lvl = next((s for s in current_supports if s['min'] == lvl['min'] and s['max'] == lvl['max']), lvl)
                    orders.append({'trade_type': 'LONG', 'level': actual_lvl, 'decision': decision})

        if allow_short:
            touched_short = [r for r in current_resistances if c_high >= r['min']]
            # SHORT_CLIMAX_MODE (см. BounceWatcher.CONFIG) — ЕДИНЫЙ переключатель:
            # False -> CLIMAX-вотчер вообще не создаётся и не ищет вход, работает
            # только MIRROR. True -> оба, как раньше. Раньше это значение читалось
            # только ПОСЛЕ создания вотчера (как override конкретному инстансу) —
            # сам список режимов для поиска был жёстко ('CLIMAX', 'MIRROR')
            # всегда, поэтому выключение в конфиге ничего не отключало.
            active_short_modes = SHORT_MODES if BounceWatcher.CONFIG.get('SHORT_CLIMAX_MODE') else ('MIRROR',)
            for mode in active_short_modes:
                focus_short_id = self._get_focus_level_id('SHORT', mode=mode, coin=coin)
                for level_id, lvl, decision in self.evaluate_bounce_side(
                        'SHORT', touched_short,
                        lambda lid, l, _mode=mode, _focus=focus_short_id: self.evaluate_bounce(
                            l, df_slice, 'SHORT', current_supports,
                            is_focus=(_focus is None or lid == _focus), c_atr=c_atr,
                            same_side_levels=current_resistances, mode=_mode, coin=coin),
                        mode=mode, coin=coin):
                    _collect_event(level_id, 'SHORT')
                    if decision.get('allow'):
                        actual_lvl = next((r for r in current_resistances if r['min'] == lvl['min'] and r['max'] == lvl['max']), lvl)
                        orders.append({'trade_type': 'SHORT', 'level': actual_lvl, 'decision': decision})

            # === ЖЕСТКОЕ УБИЙСТВО НИЖНИХ УРОВНЕЙ (только внутри семьи CLIMAX,
            # только внутри ЭТОЙ монеты — это правило "побеждает самый верхний"
            # родом из климакс-логики, MIRROR-вотчеров оно не касается вообще,
            # у них своя, независимая линия сигналов). БЕЗ фильтра по coin тут
            # был тот же баг, что и в evaluate_bounce_side — climax монеты A
            # мог убить climax монеты B, если у него max оказался ниже. ===
            searching_shorts = [
                w for w in self._watchers.values()
                if getattr(w, 'coin', None) == coin
                and getattr(w, 'trade_type', None) == 'SHORT'
                and getattr(w, 'mode', None) == 'CLIMAX'
                and getattr(w, 'climax_stage', None) == 'SEARCHING'
                and getattr(w, 'state', None) not in ("DEAD", "TRIGGERED")
            ]
            if searching_shorts:
                highest_max = max(w.max for w in searching_shorts)
                for w in self._watchers.values():
                    if getattr(w, 'coin', None) == coin and getattr(w, 'trade_type', None) == 'SHORT' and getattr(w, 'mode', None) == 'CLIMAX' and getattr(w, 'state', None) not in ("DEAD", "TRIGGERED"):
                        if w.max < highest_max:
                            w.state = "DEAD"
                            w.last_event_type = "RUNAWAY"
                            w.history_log = "Приоритет отдан более высокому уровню. Нижний сетап убит навсегда."
                            w._dbg(f"🔴 ОТМЕНА | {w.history_log}")

        return orders, draw_events
    # -------------------------------------------------------------------------
    # BOUNCE (Отбой от макро-уровня)
    # -------------------------------------------------------------------------
    def evaluate_bounce(self, level, df, trade_type, all_opposite_levels, is_focus=True,
                        c_atr=0.0, same_side_levels=None, mode=None, coin="UNKNOWN"):
        level_id = self._level_id(level, trade_type)
        if mode:
            level_id = f"{level_id}__{mode}"
        if level_id in self.burned_levels:
            return self._deny("Level already burned")

        if level_id not in self._watchers:
            config_overrides = None
            if trade_type == 'SHORT' and mode:
                # CLIMAX -> SHORT_CLIMAX_MODE=True, MIRROR -> False. Фиксируется
                # НАВСЕГДА в момент рождения вотчера, независимо от того, что
                # сейчас стоит в BounceWatcher.CONFIG по умолчанию.
                config_overrides = {'SHORT_CLIMAX_MODE': (mode == 'CLIMAX')}
            self._watchers[level_id] = BounceWatcher(level['min'], level['max'], trade_type,
                                                       config_overrides=config_overrides, mode=mode,
                                                       coin=coin, log_dir_override=self.log_dir_override)
            self._watchers[level_id].level_type = level.get('type', 'UNKNOWN')
            self._watchers[level_id].level_date = level.get('date')
            self._watchers[level_id].level_score = level.get('score', 0)
            if level.get('_reborn'):
                self._watchers[level_id].reborn = True
                self._watchers[level_id]._dbg(
                    "🪦 ВОСКРЕС | Эта зона уже была здесь и умерла раньше, "
                    "но цена уходила и вернулась — считаем новым сетапом"
                )
            if trade_type == 'SHORT' and same_side_levels:
                # Дальняя (следующая по цене выше) resistance-зона для SHORT
                # climax-логики — считается ОДИН раз, при рождении вотчера,
                # и дальше не меняется (как и сама зона вотчера).
                candidates = [r for r in same_side_levels if r['min'] > level['max']]
                if candidates:
                    farthest_near = min(candidates, key=lambda r: r['min'] - level['max'])
                    self._watchers[level_id].paired_level = dict(farthest_near)
                # Если candidates пуст — paired_level остаётся None (задан в
                # __init__ вотчера), это и есть "нет верхней зоны — не торгуем".
        watcher = self._watchers[level_id]

        if len(df) < 52:
            return self._deny("Not enough data")

        # Считаем 90-й перцентиль (отсекаем мусор и ночной флэт)
        baseline_vol = float(df['volume'].iloc[-52:-2].quantile(0.9))

        c = df.iloc[-1]
        c_open, c_high, c_low, c_close, c_vol = (
            float(c['open']), float(c['high']), float(c['low']), float(c['close']), float(c['volume'])
        )

        signal = watcher.update(
            c_open, c_high, c_low, c_close, c_vol, baseline_vol,
            all_opposite_levels, level_score=level.get('score', 0), candle_time=df.index[-1],
            is_focus=is_focus, c_atr=c_atr
        )

        if watcher.state in ("DEAD", "TRIGGERED"):
            self._record_death(watcher, trade_type, level_id)

        if not signal:
            return self._deny(f"No signal (state: {watcher.state})")

        if 'error' in signal:
            return self._deny(signal['error'])

        # Уровень НЕ сжигаем! Менеджер больше не блочит уровень.
        # Вотчер сам перейдет в DEAD, когда исчерпает лимит сделок в своем конфиге.
        # self.burned_levels.add(level_id)

        signal['allow'] = True
        signal['level_id'] = level_id
        signal['extreme_price'] = "0.0"
        signal['is_real_sweep'] = False
        signal['overshoot_pct'] = 0.0
        signal['candles_in_sweep'] = 0

        return signal

    # -------------------------------------------------------------------------
    # Хозяйство: количество вотчеров / уборка мёртвых (шаг 5)
    # -------------------------------------------------------------------------
    def watcher_count(self):
        return len(self._watchers)

    def clear_dead_watchers(self, active_level_ids):
        """Тонкая обёртка над parent.clear_dead_watchers — та же роль, что
        VBottomManager.clear_dead_watchers: убирает уже DEAD/TRIGGERED
        вотчеров, которых нет среди активных id этого скана. Не трогает
        живые (SCANNING/searching) вотчеры независимо от active_level_ids —
        см. BounceParent.clear_dead_watchers."""
        return self.parent.clear_dead_watchers(active_level_ids)

    def clear_graveyard_by_coin(self, coin):
        """Чистит кладбище (graveyard) для конкретной монеты — используется
        ручным ресканом (см. background_tasks.py). Кладбище — защита для
        ЖИВОГО сканирования: не даёт зоне, которая только что умерла,
        мгновенно "ожить" из ничего (клон/воскрешение, тег OD). Во время
        реплея прошлого пути монеты эта защита не нужна и только мешает —
        она создаёт нового вотчера-клона вместо того, чтобы обычным
        механизмом (level_id уже в _watchers) продолжить работу С ТЕМ ЖЕ
        объектом, которого мы только что сбросили через reset_for_rescan."""
        removed_ids = set()
        kept = []
        for entry in self.graveyard:
            if entry.get('coin') == coin:
                base_id = self._level_id({'min': entry['min'], 'max': entry['max']}, entry['trade_type'])
                level_id = f"{base_id}__{entry['mode']}" if entry.get('mode') else base_id
                removed_ids.add(level_id)
            else:
                kept.append(entry)
        self.graveyard = kept
        self._graveyard_recorded -= removed_ids

    def remove_watchers_by_coin(self, coin):
        """Удаляет ВСЕХ вотчеров конкретной монеты (живых и мёртвых) —
        используется ручным ресканом (см. background_tasks.py, флаг
        rescan_{coin}.flag): раз рескан честно пересобирает путь монеты
        заново от выбранной даты, старых вотчеров нужно убрать полностью,
        иначе реплей будет накладывать прошлые свечи на вотчер, который уже
        успел уйти вперёд по своему реальному состоянию — получится каша, а
        не честный повтор. В отличие от VBottomManager.remove_watchers_by_coin
        (просто del, без возврата) — тут ВОЗВРАЩАЕМ удалённых, чтобы
        background_tasks.py успел заархивировать их в watcher_history.json
        (иначе их точки просто исчезли бы бесследно, ничем не отличаясь от
        обычного стирания памяти)."""
        removed = {}
        for level_id in [k for k, w in self._watchers.items() if getattr(w, 'coin', None) == coin]:
            removed[level_id] = self._watchers.pop(level_id)
        return removed

    # -------------------------------------------------------------------------
    # Персистентность между рестартами бота (шаги 2-3). По той же схеме, что
    # VBottomManager.to_state_dict/save_state/load_state — дамп __dict__
    # каждого вотчера целиком + отдельно состояние самого менеджера
    # (pierced_count/graveyard/_graveyard_recorded), которого у VBottomManager
    # нет, потому что у него нет ни кладбища, ни счётчика пробоев.
    # -------------------------------------------------------------------------

    # Поля BounceWatcher, которые могут содержать pandas.Timestamp
    # (json.dump их не переваривает) — переводим в ISO-строку туда-обратно.
    _TIMESTAMP_FIELDS = ('_last_time', 'last_event_time', 'last_pierce_time')

    def to_state_dict(self):
        """Сериализует вотчеров BOUNCE + состояние самого менеджера
        в JSON-совместимый словарь."""
        watchers_out = {}
        for level_id, watcher in self._watchers.items():
            state = dict(watcher.__dict__)
            for ts_field in self._TIMESTAMP_FIELDS:
                val = state.get(ts_field)
                if val is not None and hasattr(val, 'isoformat'):
                    state[ts_field] = val.isoformat()
            watchers_out[level_id] = {
                'min': watcher.min,
                'max': watcher.max,
                'trade_type': watcher.trade_type,
                'mode': getattr(watcher, 'mode', None),
                'coin': getattr(watcher, 'coin', 'UNKNOWN'),
                'state': state,
            }
        return {
            'watchers': watchers_out,
            'pierced_count': self.pierced_count,
            'graveyard': self.graveyard,
            'graveyard_recorded': list(self._graveyard_recorded),
            'last_processed_time': self.last_processed_time,
        }

    def save_state(self, path):
        """Атомарно сохраняет текущее состояние BOUNCE (вотчеры + кладбище +
        счётчики) в файл. Вызывается из live_scan.py::save_watcher_state()
        раз в скан-цикл, вместе с v_bottom_mgr."""
        try:
            data = self.to_state_dict()
            tmp_path = f"{path}.tmp"
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp_path, path)
        except Exception as e:
            print(f"[BounceManager] ⚠️ Не удалось сохранить состояние BOUNCE: {e}")

    def load_state(self, path):
        """Восстанавливает вотчеров BOUNCE + graveyard + pierced_count из
        файла состояния при старте бота. Вызывается один раз при импорте
        live_scan.py, сразу после создания bounce_mgr."""
        if not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"[BounceManager] ⚠️ Не удалось прочитать состояние BOUNCE: {e}")
            return

        watchers_in = data.get('watchers', {})
        restored = 0
        for level_id, entry in watchers_in.items():
            saved_coin = entry.get('coin')
            if not saved_coin or saved_coin == 'UNKNOWN':
                print(f"[BounceManager] 🗑️ Игнорируем зомби-вотчер без монеты: {level_id}")
                continue
            try:
                mode = entry.get('mode')
                saved_state = dict(entry.get('state', {}))
                # config_overrides не хранится отдельно — он уже "запёкся"
                # внутри сохранённого self.CONFIG (см. __dict__ дамп), поэтому
                # конструктору передаём базовые аргументы, а CONFIG перезатрём
                # ниже вместе со всем остальным состоянием.
                watcher = BounceWatcher(entry['min'], entry['max'], entry['trade_type'],
                                          mode=mode, coin=saved_coin, log_dir_override=self.log_dir_override)
                for ts_field in self._TIMESTAMP_FIELDS:
                    val = saved_state.get(ts_field)
                    if val is not None:
                        try:
                            saved_state[ts_field] = pd.Timestamp(val)
                        except Exception:
                            saved_state[ts_field] = None
                watcher.__dict__.update(saved_state)
                self._watchers[level_id] = watcher
                restored += 1
            except Exception as e:
                print(f"[BounceManager] ⚠️ Пропущен BOUNCE-вотчер {level_id} при восстановлении: {e}")

        self.pierced_count = data.get('pierced_count', 0)
        self.graveyard = data.get('graveyard', [])
        self._graveyard_recorded = set(data.get('graveyard_recorded', []))
        self.last_processed_time = data.get('last_processed_time', {})

        if restored:
            print(f"[BounceManager] ✅ Восстановлено {restored} BOUNCE-вотчеров из {path}")